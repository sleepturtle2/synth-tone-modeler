Configs for the MidiAutoencoder family of models (decoding from MIDI to audio).

Configs that go:

* Synth Params -> MIDI -> Synth Params

Instead of:

* LD/DB -> MIDI -> LD/DB
