# URMP gin configs

These gin configs are for the [URMP dataset](http://www2.ece.rochester.edu/projects/air/projects/URMP.html).

To use, add the base path as a param with `--gin-param=base_path='path/to/urmp_f0_interop/'`.

To select a specific instrument, set `--gin-param=instrument_key='sax'`.
