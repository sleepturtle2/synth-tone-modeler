# Gin Configs: Optimization

This directory contains gin configs for training hyperparameters such as `batch_size`
and `learning_rate`. Default values are loaded via `ddsp_run.py` and can be replaced with the `--gin_param` flag.
